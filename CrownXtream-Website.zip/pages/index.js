export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100 text-center p-10">
      <h1 className="text-4xl font-bold mb-4">Welcome to CrownXtream Lubricants</h1>
      <p className="text-lg">High-performance lubricants for every engine.</p>
    </div>
  );
}