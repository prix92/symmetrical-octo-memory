CrownXtream Lubricants Website Deployment Guide
-----------------------------------------------

1. Go to https://vercel.com and sign in with your email (prince8692@gmail.com).
2. Click "New Project" and connect your GitHub account.
3. Create a new GitHub repository and upload all the files from this ZIP.
4. On Vercel, import that GitHub repo.
5. Use default settings (Next.js is auto-detected) and click Deploy.
6. Done! Your live site will be available at a vercel.app link.

Optional:
- Add your custom domain in Vercel's dashboard.
- You can edit the content directly in the code (e.g., in pages/index.js).